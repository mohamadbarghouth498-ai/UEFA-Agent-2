# UEFA Agent

Android project for a single-game screen analyzer.

Current version:
- Android build project.
- MediaProjection permission flow.
- Accessibility observation scaffold.
- ML Kit text-recognition dependency.
- Analysis-only mode.
- No automatic taps or betting.
- Safety thresholds documented: 499,000 warning/stop threshold and 500,000 hard stop.

The next engineering stage is to connect MediaProjection frames to OCR and a strict UEFA-only screen detector, then validate extraction against supplied screenshots. Prediction quality cannot be assumed if the game's outcomes are server-side random.
