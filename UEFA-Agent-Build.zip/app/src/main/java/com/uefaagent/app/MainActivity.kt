package com.uefaagent.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    companion object { private const val REQUEST_CAPTURE = 1001 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val status = TextView(this).apply {
            text = "UEFA Agent\n\nوضع التحليل فقط\nاللعبة المستهدفة: UEFA فقط\nحد الإيقاف: 500,000 Crystal\nحاجز الأمان: 499,000 Crystal\n\nلا توجد نقرات أو رهانات تلقائية في هذه النسخة."
            textSize = 18f
            setPadding(32, 48, 32, 32)
        }

        val start = Button(this).apply {
            text = "بدء قراءة الشاشة"
            setOnClickListener {
                val mgr = getSystemService(MediaProjectionManager::class.java)
                startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_CAPTURE)
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(start)
        }
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java)
                .putExtra("resultCode", resultCode)
                .putExtra("data", data)
            startForegroundService(intent)
        }
    }
}
