package com.uefaagent.app

import android.app.*
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.IBinder

class ScreenCaptureService : Service() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "uefa_agent_capture"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, "UEFA Agent", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("UEFA Agent")
            .setContentText("تحليل الشاشة فقط — بدون نقر تلقائي")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(7, notification)
        // MediaProjection frame acquisition and OCR are the next integration stage.
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
