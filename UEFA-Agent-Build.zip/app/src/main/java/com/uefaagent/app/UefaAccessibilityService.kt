package com.uefaagent.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class UefaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Observation scaffold only. Deliberately no click(), performAction(), or betting logic.
    }
    override fun onInterrupt() {}
}
